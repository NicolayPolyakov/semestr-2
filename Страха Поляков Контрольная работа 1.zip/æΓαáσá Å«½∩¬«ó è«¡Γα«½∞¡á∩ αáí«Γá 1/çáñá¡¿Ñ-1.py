def first_last (letter, st):
    first = st.find(letter)
    if first < 0:
        return None, None
    last = st.rfind(letter)
    return first, last
print(first_last('a', 'abba'))
print(first_last('a', 'abbaaaab'))
print(first_last('a', 'a'))
print(first_last('a', 'spring'))