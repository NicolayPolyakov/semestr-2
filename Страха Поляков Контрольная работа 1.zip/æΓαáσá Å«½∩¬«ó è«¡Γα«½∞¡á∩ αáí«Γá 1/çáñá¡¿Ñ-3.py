import re
def shortener(st):
    cleaned_text = re.sub(r'\([^)]*\)', '', st)
    return cleaned_text
text = 'любой (текст) для кода'
result = shortener(text)
print(result)